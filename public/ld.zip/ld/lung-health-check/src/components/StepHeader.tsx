interface StepHeaderProps {
  step: number;
  totalSteps: number;
  title: string;
  subtitle?: string;
  progress?: number;
}

const StepHeader = ({ step, totalSteps, title, subtitle, progress }: StepHeaderProps) => {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-primary">
            Step {step} of {totalSteps}
          </p>
          <h1 className="mt-1 text-2xl font-bold text-foreground">{title}</h1>
          {subtitle && <p className="mt-1 text-muted-foreground">{subtitle}</p>}
        </div>
        {progress !== undefined && (
          <div className="text-right">
            <span className="text-lg font-bold text-primary">{progress}%</span>
            <p className="text-xs text-muted-foreground">Complete</p>
          </div>
        )}
      </div>
      <div className="mt-3 h-1 w-full rounded-full bg-muted">
        <div
          className="h-1 rounded-full bg-primary transition-all duration-500"
          style={{ width: `${(step / totalSteps) * 100}%` }}
        />
      </div>
    </div>
  );
};

export default StepHeader;
