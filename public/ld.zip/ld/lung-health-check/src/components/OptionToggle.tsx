import { cn } from "@/lib/utils";

interface OptionToggleProps {
  options: string[];
  value: string;
  onChange: (value: string) => void;
}

const OptionToggle = ({ options, value, onChange }: OptionToggleProps) => {
  return (
    <div className="flex gap-2">
      {options.map((option) => (
        <button
          key={option}
          type="button"
          onClick={() => onChange(option)}
          className={cn(
            "rounded-lg px-4 py-2 text-sm font-medium transition-all",
            value === option
              ? "bg-primary text-primary-foreground shadow-elevated"
              : "bg-muted text-muted-foreground hover:bg-accent"
          )}
        >
          {option}
        </button>
      ))}
    </div>
  );
};

export default OptionToggle;
