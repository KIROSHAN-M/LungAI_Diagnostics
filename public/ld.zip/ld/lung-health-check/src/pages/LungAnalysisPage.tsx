import { useState, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Upload, ImageIcon, Loader2, AlertTriangle, CheckCircle2, ArrowRight,
  Sparkles, Target, TrendingUp, Zap, Activity, ShieldCheck, Brain,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import StepHeader from "@/components/StepHeader";
import { analyzeXray } from "@/lib/analyzeXray";
import type { DiagnosisResult } from "@/types/patient";

/* ── Metric card ────────────────────────────── */
const MetricCard = ({ icon: Icon, label, value, color }: { icon: typeof Sparkles; label: string; value: number; color: string }) => (
  <div className="group relative overflow-hidden rounded-2xl border border-border bg-card p-4 transition-shadow hover:shadow-elevated">
    <div className="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-accent opacity-50 transition-transform group-hover:scale-150" />
    <div className="relative">
      <div className="mb-2 flex items-center gap-1.5">
        <Icon className={`h-4 w-4 ${color}`} />
        <span className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">{label}</span>
      </div>
      <p className="text-2xl font-extrabold text-foreground">{value}%</p>
      <Progress value={value} className="mt-2 h-1.5" />
    </div>
  </div>
);

/* ── Feature pill ───────────────────────────── */
const FeaturePill = ({ icon: Icon, text }: { icon: typeof Brain; text: string }) => (
  <div className="flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm text-muted-foreground shadow-card">
    <Icon className="h-4 w-4 text-primary" />
    {text}
  </div>
);

/* ── Main page ──────────────────────────────── */
const LungAnalysisPage = () => {
  const navigate = useNavigate();
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [result, setResult] = useState<DiagnosisResult | null>(null);
  const [dragOver, setDragOver] = useState(false);

  useEffect(() => {
    const patientInfo = sessionStorage.getItem("patientInfo");
    if (!patientInfo) {
      toast.error("Please fill in patient information first");
      navigate("/patient-info");
    }
  }, [navigate]);

  const processFile = useCallback(async (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast.error("Please upload an image file (PNG, JPG)");
      return;
    }
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = async (e) => {
      const dataUrl = e.target?.result as string;
      setImagePreview(dataUrl);
      setIsAnalyzing(true);
      setResult(null);
      setAnalysisProgress(0);

      const interval = setInterval(() => {
        setAnalysisProgress((p) => {
          if (p >= 90) { clearInterval(interval); return 90; }
          return p + Math.random() * 12;
        });
      }, 200);

      const diagnosis = await analyzeXray(dataUrl);
      clearInterval(interval);
      setAnalysisProgress(100);

      setTimeout(() => {
        setIsAnalyzing(false);
        setResult(diagnosis);
        sessionStorage.setItem("diagnosis", JSON.stringify(diagnosis));
      }, 500);
    };
    reader.readAsDataURL(file);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  }, [processFile]);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <div className="border-b border-border bg-card/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
          <div className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-primary" />
            <span className="text-sm font-bold text-foreground">LungAI Diagnostics</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <ShieldCheck className="h-4 w-4 text-success" />
            HIPAA Compliant · Local Processing
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-6 py-8">
        <StepHeader
          step={2}
          totalSteps={3}
          title="Chest X-Ray Analysis"
          subtitle="Upload a PA or AP chest radiograph for AI-powered pneumonia screening."
        />

        {!result ? (
          <div className="grid gap-8 lg:grid-cols-5">
            {/* Upload — spans 3 cols */}
            <div className="lg:col-span-3">
              <label
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
                className={`flex cursor-pointer flex-col items-center justify-center rounded-3xl border-2 border-dashed transition-all duration-300 ${
                  dragOver
                    ? "border-primary bg-accent shadow-elevated"
                    : "border-border bg-card hover:border-primary/40 hover:shadow-card"
                } ${imagePreview ? "min-h-[340px]" : "min-h-[380px]"} p-10`}
              >
                {imagePreview ? (
                  <div className="text-center">
                    <div className="mx-auto overflow-hidden rounded-2xl border border-border shadow-card">
                      <img src={imagePreview} alt="X-ray" className="mx-auto max-h-64 object-contain" />
                    </div>
                    <p className="mt-4 text-sm font-medium text-muted-foreground">{fileName}</p>
                  </div>
                ) : (
                  <>
                    <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-accent shadow-card">
                      <Upload className="h-7 w-7 text-primary" />
                    </div>
                    <p className="text-lg font-bold text-foreground">Drop chest X-ray here</p>
                    <p className="mt-1 text-sm text-muted-foreground">PNG, JPG — Click to browse</p>
                    <div className="mt-6 flex flex-wrap justify-center gap-2">
                      <FeaturePill icon={Brain} text="Deep Learning" />
                      <FeaturePill icon={Target} text="Pneumonia Detection" />
                      <FeaturePill icon={Zap} text="Instant Results" />
                    </div>
                  </>
                )}
                <input type="file" accept="image/*" onChange={handleFileInput} className="hidden" />
              </label>
            </div>

            {/* Side panel — spans 2 cols */}
            <div className="flex flex-col items-center justify-center rounded-3xl border border-border bg-card p-10 shadow-card lg:col-span-2">
              {isAnalyzing ? (
                <div className="w-full text-center">
                  <div className="relative mx-auto mb-6 h-20 w-20">
                    <div className="absolute inset-0 animate-ping rounded-full bg-primary/20" />
                    <div className="relative flex h-full w-full items-center justify-center rounded-full bg-accent">
                      <Loader2 className="h-10 w-10 animate-spin text-primary" />
                    </div>
                  </div>
                  <p className="text-lg font-bold text-foreground">Analyzing X-ray…</p>
                  <p className="mt-1 text-sm text-muted-foreground">Running neural network inference</p>
                  <Progress value={analysisProgress} className="mt-6 h-2" />
                  <p className="mt-2 text-xs font-semibold text-primary">{Math.round(analysisProgress)}%</p>
                </div>
              ) : (
                <>
                  <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-muted">
                    <ImageIcon className="h-7 w-7 text-muted-foreground" />
                  </div>
                  <p className="text-lg font-bold text-foreground">Awaiting Upload</p>
                  <p className="mt-1 text-center text-sm text-muted-foreground">
                    Upload a chest X-ray to begin<br />AI-powered pneumonia screening
                  </p>
                  <div className="mt-6 w-full space-y-2 rounded-2xl bg-muted/50 p-4">
                    <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Model Info</p>
                    <div className="flex justify-between text-sm"><span className="text-muted-foreground">Architecture</span><span className="font-medium text-foreground">CNN ResNet-50</span></div>
                    <div className="flex justify-between text-sm"><span className="text-muted-foreground">Accuracy</span><span className="font-medium text-foreground">~94%</span></div>
                    <div className="flex justify-between text-sm"><span className="text-muted-foreground">Classes</span><span className="font-medium text-foreground">Normal / Pneumonia</span></div>
                  </div>
                </>
              )}
            </div>
          </div>
        ) : (
          /* ── Results ───────────────────────────── */
          <div className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-5">
              {/* X-ray preview */}
              <div className="flex flex-col items-center justify-center rounded-3xl border border-border bg-card p-6 shadow-card lg:col-span-2">
                <div className="overflow-hidden rounded-2xl border border-border">
                  <img src={imagePreview!} alt="X-ray" className="max-h-80 object-contain" />
                </div>
                <p className="mt-3 text-sm text-muted-foreground">{fileName}</p>
              </div>

              {/* Diagnosis + metrics */}
              <div className="space-y-4 lg:col-span-3">
                {/* Diagnosis banner */}
                <div className={`rounded-3xl p-6 ${
                  result.condition === "Pneumonia"
                    ? "border border-destructive/20 bg-destructive/5"
                    : "border border-success/20 bg-success/5"
                }`}>
                  <div className="flex items-start gap-4">
                    <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl ${
                      result.condition === "Pneumonia" ? "bg-destructive/10" : "bg-success/10"
                    }`}>
                      {result.condition === "Pneumonia"
                        ? <AlertTriangle className="h-6 w-6 text-destructive" />
                        : <CheckCircle2 className="h-6 w-6 text-success" />}
                    </div>
                    <div>
                      <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">AI Diagnosis</p>
                      <p className={`text-2xl font-extrabold ${
                        result.condition === "Pneumonia" ? "text-destructive" : "text-success"
                      }`}>
                        {result.condition === "Pneumonia" ? "Pneumonia Detected" : "Normal — No Pneumonia"}
                      </p>
                      <div className="mt-2 flex flex-wrap items-center gap-3 text-sm">
                        <span className="rounded-full bg-card px-3 py-1 font-semibold text-foreground shadow-card">
                          {result.confidence}% Confidence
                        </span>
                        {result.condition === "Pneumonia" && (
                          <>
                            <span className={`rounded-full px-3 py-1 text-xs font-bold ${
                              result.severity === "MILD" ? "bg-warning/20 text-warning" :
                              result.severity === "MODERATE" ? "bg-warning/30 text-warning" :
                              "bg-destructive/20 text-destructive"
                            }`}>{result.severity}</span>
                            <span className="text-muted-foreground">{result.lungAreaAffected}% affected</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Condition chip */}
                <div className="rounded-2xl border border-border bg-card p-5 shadow-card">
                  <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Detected Conditions</p>
                  <div className="mt-3 flex items-center gap-2">
                    <span className={`h-3 w-3 rounded-full ${
                      result.condition === "Pneumonia" ? "bg-destructive" : "bg-success"
                    }`} />
                    <span className="font-semibold text-foreground">
                      {result.condition === "Pneumonia" ? "Pneumonia" : "No abnormalities detected"}
                    </span>
                  </div>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-2 gap-3">
                  <MetricCard icon={Sparkles} label="Accuracy" value={result.accuracy} color="text-primary" />
                  <MetricCard icon={Target} label="Precision" value={result.precision} color="text-primary" />
                  <MetricCard icon={TrendingUp} label="Recall" value={result.recall} color="text-primary" />
                  <MetricCard icon={Zap} label="F1 Score" value={result.f1Score} color="text-primary" />
                </div>
              </div>
            </div>

            {/* Analysis text */}
            <div className="rounded-3xl border border-border bg-card p-6 shadow-card">
              <p className="mb-3 text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Deep Learning Model Analysis</p>
              <p className="leading-relaxed text-muted-foreground">{result.analysis}</p>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap justify-between gap-4">
              <Button variant="outline" onClick={() => { setResult(null); setImagePreview(null); }} className="rounded-xl">
                Upload Another X-ray
              </Button>
              {result.condition === "Pneumonia" ? (
                <Button variant="cta" size="lg" onClick={() => navigate("/treatment-plan")} className="rounded-xl px-8">
                  View Treatment Plan <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Button variant="cta" size="lg" onClick={() => toast.success("No treatment needed — lungs are healthy!")} className="rounded-xl px-8">
                  No Treatment Required <CheckCircle2 className="ml-2 h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LungAnalysisPage;
