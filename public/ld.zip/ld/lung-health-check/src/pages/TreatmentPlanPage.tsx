import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AlertTriangle, Pill, Apple, Clock } from "lucide-react";
import StepHeader from "@/components/StepHeader";
import type { DiagnosisResult } from "@/types/patient";

const medications = [
  { name: "Amoxicillin 500mg", instruction: "Take with food to reduce stomach upset", frequency: "Every 8 hours", duration: "7-10 days" },
  { name: "Azithromycin 250mg", instruction: "Take 1 hour before meals", frequency: "Once daily", duration: "5 days" },
  { name: "Paracetamol 650mg", instruction: "For fever and pain relief, max 4g/day", frequency: "Every 6 hours as needed", duration: "As required" },
  { name: "Guaifenesin 200mg", instruction: "Expectorant to loosen mucus", frequency: "Every 4 hours", duration: "5-7 days" },
];

const dietTips = [
  { text: "Warm soups and broths — chicken soup helps reduce inflammation and provides hydration", color: "bg-primary" },
  { text: "Citrus fruits (oranges, lemons) — rich in Vitamin C to boost immunity", color: "bg-primary" },
  { text: "Leafy green vegetables — spinach, kale for iron and antioxidants", color: "bg-success" },
  { text: "Ginger and turmeric tea — natural anti-inflammatory properties", color: "bg-success" },
  { text: "Honey with warm water — soothes throat and has antibacterial properties", color: "bg-warning" },
  { text: "Protein-rich foods — eggs, lean chicken, fish for tissue repair", color: "bg-warning" },
  { text: "Avoid cold drinks, fried food, and dairy products during recovery", color: "bg-destructive" },
];

const TreatmentPlanPage = () => {
  const navigate = useNavigate();
  const [diagnosis, setDiagnosis] = useState<DiagnosisResult | null>(null);

  useEffect(() => {
    const data = sessionStorage.getItem("diagnosis");
    if (!data) {
      navigate("/lung-analysis");
      return;
    }
    const parsed = JSON.parse(data) as DiagnosisResult;
    if (parsed.condition !== "Pneumonia") {
      navigate("/lung-analysis");
      return;
    }
    setDiagnosis(parsed);
  }, [navigate]);

  if (!diagnosis) return null;

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-3xl">
        <StepHeader step={3} totalSteps={3} title="Treatment & Care Plan" />

        {/* Diagnosis badge */}
        <div className="mb-6 flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-destructive/10 px-3 py-1 text-sm font-semibold text-destructive">
            <AlertTriangle className="h-3.5 w-3.5" /> Pneumonia
          </span>
          <span className="text-sm text-muted-foreground">• {diagnosis.severity}</span>
          <span className="text-sm text-muted-foreground">• {diagnosis.lungAreaAffected}% affected</span>
        </div>

        {/* Medications */}
        <div className="rounded-2xl bg-card p-6 shadow-card">
          <div className="mb-4 flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
              <Pill className="h-4 w-4 text-primary" />
            </div>
            <h2 className="font-semibold text-foreground">Recommended Medications</h2>
          </div>

          <div className="space-y-3">
            {medications.map((med) => (
              <div key={med.name} className="flex items-center justify-between rounded-xl border border-border p-4">
                <div>
                  <p className="font-semibold text-foreground">{med.name}</p>
                  <p className="text-sm text-muted-foreground">{med.instruction}</p>
                </div>
                <div className="text-right">
                  <p className="flex items-center gap-1 text-sm font-medium text-primary">
                    <Clock className="h-3.5 w-3.5" /> {med.frequency}
                  </p>
                  <p className="text-xs text-muted-foreground">{med.duration}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Diet & Nutrition */}
        <div className="mt-6 rounded-2xl bg-card p-6 shadow-card">
          <div className="mb-4 flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-success/10">
              <Apple className="h-4 w-4 text-success" />
            </div>
            <h2 className="font-semibold text-foreground">Diet & Nutrition</h2>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            {dietTips.map((tip, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${tip.color}`} />
                <p className="text-sm text-muted-foreground">{tip.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TreatmentPlanPage;
