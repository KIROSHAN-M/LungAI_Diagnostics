import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { User, HeartPulse, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import StepHeader from "@/components/StepHeader";
import OptionToggle from "@/components/OptionToggle";
import type { PatientInfo } from "@/types/patient";

const PatientInfoPage = () => {
  const navigate = useNavigate();
  const [info, setInfo] = useState<PatientInfo>({
    fullName: "", age: "", height: "", weight: "", gender: "",
    bloodPressure: "", currentProblem: "", symptoms: "",
    smokingHistory: "", asthma: "", previousRespIssues: "", knownAllergies: "",
  });

  const update = (field: keyof PatientInfo, value: string) =>
    setInfo((prev) => ({ ...prev, [field]: value }));

  const progress = Math.round(
    (Object.values(info).filter(Boolean).length / Object.keys(info).length) * 100
  );

  const handleProceed = () => {
    if (!info.fullName.trim()) { toast.error("Full name is required"); return; }
    if (!info.age || isNaN(Number(info.age)) || Number(info.age) < 1 || Number(info.age) > 150) {
      toast.error("Please enter a valid age (1-150)"); return;
    }
    if (!info.gender) { toast.error("Please select a gender"); return; }
    if (!info.symptoms.trim()) { toast.error("Please describe symptoms"); return; }
    if (!info.smokingHistory) { toast.error("Please select smoking history"); return; }
    if (!info.asthma) { toast.error("Please select asthma status"); return; }
    if (!info.previousRespIssues) { toast.error("Please select previous respiratory issues"); return; }

    sessionStorage.setItem("patientInfo", JSON.stringify(info));
    navigate("/lung-analysis");
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-4xl">
        <StepHeader step={1} totalSteps={3} title="Patient Information" progress={progress} />

        <div className="grid gap-6 md:grid-cols-2">
          {/* Basic Information */}
          <div className="rounded-2xl bg-card p-6 shadow-card">
            <div className="mb-5 flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent">
                <User className="h-4 w-4 text-accent-foreground" />
              </div>
              <h2 className="font-semibold text-foreground">Basic Information</h2>
            </div>

            <div className="space-y-4">
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Full Name</Label>
                <Input placeholder="John Doe" value={info.fullName} onChange={(e) => update("fullName", e.target.value)} className="mt-1 h-11 rounded-xl bg-muted/50" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Age</Label>
                  <Input type="number" placeholder="45" value={info.age} onChange={(e) => update("age", e.target.value)} className="mt-1 h-11 rounded-xl bg-muted/50" />
                </div>
                <div>
                  <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Height (cm)</Label>
                  <Input type="number" placeholder="170" value={info.height} onChange={(e) => update("height", e.target.value)} className="mt-1 h-11 rounded-xl bg-muted/50" />
                </div>
                <div>
                  <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Weight (kg)</Label>
                  <Input type="number" placeholder="70" value={info.weight} onChange={(e) => update("weight", e.target.value)} className="mt-1 h-11 rounded-xl bg-muted/50" />
                </div>
              </div>
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Gender</Label>
                <div className="mt-2">
                  <OptionToggle options={["Male", "Female", "Other"]} value={info.gender} onChange={(v) => update("gender", v)} />
                </div>
              </div>
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Blood Pressure</Label>
                <Input placeholder="120/80 mmHg" value={info.bloodPressure} onChange={(e) => update("bloodPressure", e.target.value)} className="mt-1 h-11 rounded-xl bg-muted/50" />
              </div>
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Current Problem</Label>
                <Input placeholder="Persistent cough, chest pain..." value={info.currentProblem} onChange={(e) => update("currentProblem", e.target.value)} className="mt-1 h-11 rounded-xl bg-muted/50" />
              </div>
            </div>
          </div>

          {/* Clinical History */}
          <div className="rounded-2xl bg-card p-6 shadow-card">
            <div className="mb-5 flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-success/20">
                <HeartPulse className="h-4 w-4 text-success" />
              </div>
              <h2 className="font-semibold text-foreground">Clinical History</h2>
            </div>

            <div className="space-y-4">
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Symptoms</Label>
                <Textarea placeholder="Shortness of breath, fever, wheezing, fatigue..." value={info.symptoms} onChange={(e) => update("symptoms", e.target.value)} className="mt-1 rounded-xl bg-muted/50" rows={3} />
              </div>
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Smoking History</Label>
                <div className="mt-2">
                  <OptionToggle options={["Never", "Former", "Current"]} value={info.smokingHistory} onChange={(v) => update("smokingHistory", v)} />
                </div>
              </div>
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Asthma</Label>
                <div className="mt-2">
                  <OptionToggle options={["No", "Mild", "Moderate", "Severe"]} value={info.asthma} onChange={(v) => update("asthma", v)} />
                </div>
              </div>
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Previous Respiratory Issues</Label>
                <div className="mt-2">
                  <OptionToggle options={["None", "Asthma", "COPD", "Other"]} value={info.previousRespIssues} onChange={(v) => update("previousRespIssues", v)} />
                </div>
              </div>
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Known Allergies</Label>
                <Textarea placeholder="Penicillin, dust, pollen..." value={info.knownAllergies} onChange={(e) => update("knownAllergies", e.target.value)} className="mt-1 rounded-xl bg-muted/50" rows={3} />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 flex justify-end">
          <Button variant="cta" size="lg" onClick={handleProceed} className="rounded-xl px-8">
            Proceed to Lung Analysis <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PatientInfoPage;
