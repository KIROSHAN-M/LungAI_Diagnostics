export interface PatientInfo {
  fullName: string;
  age: string;
  height: string;
  weight: string;
  gender: "Male" | "Female" | "Other" | "";
  bloodPressure: string;
  currentProblem: string;
  symptoms: string;
  smokingHistory: "Never" | "Former" | "Current" | "";
  asthma: "No" | "Mild" | "Moderate" | "Severe" | "";
  previousRespIssues: "None" | "Asthma" | "COPD" | "Other" | "";
  knownAllergies: string;
}

export interface DiagnosisResult {
  condition: "Normal" | "Pneumonia";
  confidence: number;
  severity: "NONE" | "MILD" | "MODERATE" | "SEVERE";
  lungAreaAffected: number;
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  analysis: string;
}
